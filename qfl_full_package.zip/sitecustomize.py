import decimal
from decimal import Decimal

def _log(msg):
    try:
        print(f"[LOT_PATCH] {msg}", flush=True)
    except Exception:
        pass

_LOT_CACHE = {}
def _fetch_lot_step(symbol: str) -> str:
    if symbol in _LOT_CACHE:
        return _LOT_CACHE[symbol]
    try:
        import requests, json, urllib.request
        try:
            data = requests.get("https://api.binance.com/api/v3/exchangeInfo", timeout=6).json()
        except Exception:
            with urllib.request.urlopen("https://api.binance.com/api/v3/exchangeInfo", timeout=8) as resp:
                data = json.loads(resp.read().decode())
        for s in data.get("symbols", []):
            if s.get("symbol") == symbol:
                for f in s.get("filters", []):
                    if f.get("filterType") == "LOT_SIZE":
                        _LOT_CACHE[symbol] = f.get("stepSize", "0")
                        return _LOT_CACHE[symbol]
    except Exception as e:
        _log(f"fetch step error: {e}")
    _LOT_CACHE[symbol] = "0"
    return "0"

def _align_qty_for_lot(symbol: str, qty: float) -> float:
    try:
        step = _fetch_lot_step(symbol)
        dstep = Decimal(step)
        if dstep == 0:
            return float(qty)
        dq = Decimal(str(qty))
        n  = (dq / dstep).to_integral_value(rounding=decimal.ROUND_DOWN)
        return float(n * dstep)
    except Exception as e:
        _log(f"align err: {e}")
        return float(qty)

try:
    from binance.client import Client
    _orig_buy  = Client.order_market_buy
    _orig_sell = Client.order_market_sell

    def _wrap_buy(self, **kw):
        sym = kw.get("symbol"); q = kw.get("quantity")
        if sym and q is not None:
            newq = _align_qty_for_lot(sym, float(q))
            if newq != q:
                _log(f"{sym} BUY qty aligned {q} -> {newq}")
            kw["quantity"] = newq
        return _orig_buy(self, **kw)

    def _wrap_sell(self, **kw):
        sym = kw.get("symbol"); q = kw.get("quantity")
        if sym and q is not None:
            newq = _align_qty_for_lot(sym, float(q))
            if newq != q:
                _log(f"{sym} SELL qty aligned {q} -> {newq}")
            kw["quantity"] = newq
        return _orig_sell(self, **kw)

    Client.order_market_buy  = _wrap_buy
    Client.order_market_sell = _wrap_sell
    _log("python-binance order methods wrapped (LOT_SIZE alignment active)")
except Exception as e:
    _log(f"wrap skipped: {e}")
