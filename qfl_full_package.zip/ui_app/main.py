import os
import re
from pathlib import Path
from typing import List, Dict, Any
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, HTMLResponse

app = FastAPI(title="QFL 控制面板", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_methods=["*"], allow_headers=["*"]
)

QFL_BOT_URL = os.environ.get("QFL_BOT_URL", "http://qfl-bot:8765")
LOG_PATH = "/app/logs/qfl_bot.log"

@app.get("/health")
async def health():
    import time
    return {"ok": True, "ts": time.strftime("%Y-%m-%d %H:%M:%S")}

@app.get("/balances")
async def balances():
    try:
        import httpx
        async with httpx.AsyncClient(timeout=8) as s:
            r = await s.get(f"{QFL_BOT_URL}/balances")
            if r.status_code == 200:
                return JSONResponse(content=r.json())
    except Exception as e:
        return JSONResponse(content={"ok": False, "reason": f"proxy_error: {e}"})
    return JSONResponse(content={"ok": False, "reason": "no_backend"})

SYM_RE   = re.compile(r"\[(?P<sym>[A-Z]{3,}USDT)\]")
ENTRY_RE = re.compile(r"ENTRY\s*->.*?avg=(?P<avg>[0-9.]+).*?qty=(?P<qty>[0-9.]+)")
DCA_RE   = re.compile(r"DCA\s*(?P<dp>[-0-9.]+)%.*?avg=(?P<avg>[0-9.]+).*?(pos|qty)=(?P<qty>[0-9.]+)")
SELL_RE  = re.compile(r"(SELL|CLOSE).*?ALL|reset_position")
TT_RE    = re.compile(r"min_gain=(?P<mg>[0-9.]+)%.+offset=(?P<of>[0-9.]+)%")

def parse_positions_from_log(max_lines: int = 6000) -> List[Dict[str, Any]]:
    p = Path(LOG_PATH)
    if not p.exists(): return []
    lines = p.read_text(encoding="utf-8", errors="ignore").splitlines()[-max_lines:]
    items: Dict[str, Dict[str, Any]] = {}
    for line in lines:
        m = SYM_RE.search(line); sym = m.group("sym") if m else None
        if not sym: continue
        it = items.get(sym) or {"symbol":sym,"qty":0.0,"avg_price":0.0,"entry_price":None,
                                "trailing":{"min_gain_pct":2.0,"offset_pct":0.2},
                                "base_fills":[], "dca_fills":[]}
        mt = TT_RE.search(line)
        if mt:
            it["trailing"] = {"min_gain_pct": float(mt.group("mg")), "offset_pct": float(mt.group("of"))}
        me = ENTRY_RE.search(line)
        if me:
            avg=float(me.group("avg")); qty=float(me.group("qty"))
            it.update({"avg_price":avg, "entry_price":avg, "qty":qty})
        md = DCA_RE.search(line)
        if md:
            avg=float(md.group("avg")); qty=float(md.group("qty"))
            it.update({"avg_price":avg, "qty":qty})
        if SELL_RE.search(line):
            it.update({"avg_price":0.0, "entry_price":None, "qty":0.0})
        items[sym]=it
    return list(items.values())

@app.get("/positions")
async def positions():
    try:
        import httpx
        async with httpx.AsyncClient(timeout=6) as s:
            r = await s.get(f"{QFL_BOT_URL}/positions")
            if r.status_code == 200:
                data = r.json()
                if isinstance(data, dict) and "items" in data:
                    return JSONResponse(content=data)
                if isinstance(data, list):
                    return JSONResponse(content={"ok": True, "items": data})
    except Exception:
        pass
    items = parse_positions_from_log()
    return JSONResponse(content={"ok": True, "items": items, "source": "ui-log"})

INDEX_HTML = """
<!doctype html>
<html>
<head>
<meta charset="utf-8"/>
<title>QFL 控制面板</title>
<style>
body{font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica,Arial,"PingFang SC","Hiragino Sans GB","Microsoft YaHei",sans-serif;margin:24px;}
h2{margin:0 0 12px 0}
small{color:#666}
button{padding:6px 10px;border:1px solid #ddd;border-radius:6px;background:#fafafa;cursor:pointer}
pre{white-space:pre-wrap;background:#f6f8fa;padding:12px;border-radius:6px;border:1px solid #eee}
</style>
</head>
<body>
  <h2>QFL 控制面板 <small>(UI)</small></h2>
  <div id="health">健康检查中...</div>
  <div style="margin:10px 0;">
    <button onclick="reloadPositions()">刷新 /positions</button>
  </div>
  <pre id="positions">载入中...</pre>
<script>
async function reloadHealth(){
  try{
    const r = await fetch('/health'); const j = await r.json();
    document.getElementById('health').innerText = '健康: ' + JSON.stringify(j);
  }catch(e){ document.getElementById('health').innerText = '健康: 请求失败 '+e; }
}
async function reloadPositions(){
  try{
    const r = await fetch('/positions'); const j = await r.json();
    document.getElementById('positions').innerText = JSON.stringify(j, null, 2);
  }catch(e){ document.getElementById('positions').innerText = '请求失败 '+e; }
}
reloadHealth(); reloadPositions();
</script>
</body>
</html>
"""

@app.get("/", response_class=HTMLResponse)
async def index():
    return HTMLResponse(INDEX_HTML)
