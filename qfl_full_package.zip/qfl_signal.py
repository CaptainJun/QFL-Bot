# -*- coding: utf-8 -*-
from typing import Sequence, Tuple, Optional

def qfl_entry_signal(
    closes: Sequence[float],
    lookback_bars: int = 50,
    drop_trigger_pct: float = 2.5,
    confirm_recovery_pct: float = 1.0,
    logger=None
) -> Tuple[bool, Optional[dict]]:
    n = len(closes)
    if n < max(lookback_bars, 10):
        if logger: logger.info(f"[QFL] signal=False reason=insufficient_bars n={n}")
        return False, None

    window = list(map(float, closes[-lookback_bars:]))
    last = float(window[-1])
    peak = max(window)
    trough = min(window)

    # 跌幅（相对峰值）
    drawdown_pct = (peak - last) / peak * 100.0 if peak > 0 else 0.0
    # 反弹（相对近端低点）
    recovery_pct = (last - trough) / trough * 100.0 if trough > 0 else 0.0

    drop_ok = (drawdown_pct >= drop_trigger_pct)
    confirm_ok = (recovery_pct >= confirm_recovery_pct)

    detail = dict(
        last=round(last, 8), peak=round(peak, 8), trough=round(trough, 8),
        drawdown_pct=round(drawdown_pct, 6),
        recovery_pct=round(recovery_pct, 6),
        drop_trigger_pct=drop_trigger_pct,
        confirm_recovery_pct=confirm_recovery_pct
    )

    if drop_ok and confirm_ok:
        if logger: logger.info(f"[QFL] signal=True {detail}")
        return True, detail
    else:
        if logger: logger.info(f"[QFL] signal=False {detail}")
        return False, detail
